﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Order_Type : Form
    {
        public Order_Type()
        {
            InitializeComponent();
        }

        private void label23_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Close(); 
        }

        private void label24_Click(object sender, EventArgs e)
        {
            new Order_Summ().Show();
            this.Close(); 
        }

        private void label25_Click(object sender, EventArgs e)
        {
            new AccountPage().Show();
            this.Close(); 
        }

        private void label17_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Close(); 
        }

        private void label3_Click(object sender, EventArgs e)
        {
            new Form2().Show();
            this.Close();
        }
    }
}
