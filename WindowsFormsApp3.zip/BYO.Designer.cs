﻿namespace $safeprojectname$
{
    partial class BYO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BYO));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.size = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.sauce = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.notes = new System.Windows.Forms.TextBox();
            this.pepp = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.crust = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.beef = new System.Windows.Forms.CheckBox();
            this.sausage = new System.Windows.Forms.CheckBox();
            this.ham = new System.Windows.Forms.CheckBox();
            this.bacon = new System.Windows.Forms.CheckBox();
            this.chicken = new System.Windows.Forms.CheckBox();
            this.mush = new System.Windows.Forms.CheckBox();
            this.onion = new System.Windows.Forms.CheckBox();
            this.greenPepp = new System.Windows.Forms.CheckBox();
            this.tomato = new System.Windows.Forms.CheckBox();
            this.pine = new System.Windows.Forms.CheckBox();
            this.bolives = new System.Windows.Forms.CheckBox();
            this.jalapeno = new System.Windows.Forms.CheckBox();
            this.spin = new System.Windows.Forms.CheckBox();
            this.exCheese = new System.Windows.Forms.CheckBox();
            this.feta = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(433, 18);
            this.label3.MinimumSize = new System.Drawing.Size(430, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(430, 80);
            this.label3.TabIndex = 7;
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(0, -1);
            this.label2.MaximumSize = new System.Drawing.Size(300, 500);
            this.label2.MinimumSize = new System.Drawing.Size(190, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 200);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(412, 647);
            this.label1.MinimumSize = new System.Drawing.Size(430, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(430, 60);
            this.label1.TabIndex = 8;
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(534, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Choose your Size!";
            // 
            // size
            // 
            this.size.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.size.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.size.FormattingEnabled = true;
            this.size.Items.AddRange(new object[] {
            "Small($7.99)",
            "Medium($9.99)",
            "Large($12.99)",
            "Xtra-Large($14.99) "});
            this.size.Location = new System.Drawing.Point(544, 125);
            this.size.Name = "size";
            this.size.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.size.Size = new System.Drawing.Size(168, 28);
            this.size.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(534, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "Choose your Sauce!";
            // 
            // sauce
            // 
            this.sauce.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sauce.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sauce.FormattingEnabled = true;
            this.sauce.Items.AddRange(new object[] {
            "Red Sauce",
            "Alfredo",
            "Barbecue"});
            this.sauce.Location = new System.Drawing.Point(561, 206);
            this.sauce.Name = "sauce";
            this.sauce.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.sauce.Size = new System.Drawing.Size(140, 32);
            this.sauce.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(199, 326);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "MEATS ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(199, 398);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "VEGGIES/OTHER";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(534, 535);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 25);
            this.label8.TabIndex = 15;
            this.label8.Text = "Special Notes";
            // 
            // notes
            // 
            this.notes.AccessibleName = "";
            this.notes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.notes.Location = new System.Drawing.Point(513, 565);
            this.notes.MaximumSize = new System.Drawing.Size(250, 100);
            this.notes.MinimumSize = new System.Drawing.Size(150, 70);
            this.notes.Multiline = true;
            this.notes.Name = "notes";
            this.notes.Size = new System.Drawing.Size(226, 70);
            this.notes.TabIndex = 17;
            // 
            // pepp
            // 
            this.pepp.AutoSize = true;
            this.pepp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pepp.FlatAppearance.BorderSize = 0;
            this.pepp.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.pepp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pepp.ForeColor = System.Drawing.SystemColors.Window;
            this.pepp.Location = new System.Drawing.Point(245, 362);
            this.pepp.Name = "pepp";
            this.pepp.Size = new System.Drawing.Size(126, 28);
            this.pepp.TabIndex = 24;
            this.pepp.Text = "Pepperoni";
            this.pepp.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Image = ((System.Drawing.Image)(resources.GetObject("label23.Image")));
            this.label23.Location = new System.Drawing.Point(25, 589);
            this.label23.MinimumSize = new System.Drawing.Size(70, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 100);
            this.label23.TabIndex = 46;
            this.label23.Text = "label23";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
            this.label24.Location = new System.Drawing.Point(129, 585);
            this.label24.MinimumSize = new System.Drawing.Size(70, 100);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 100);
            this.label24.TabIndex = 47;
            this.label24.Text = "label24";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Image = ((System.Drawing.Image)(resources.GetObject("label25.Image")));
            this.label25.Location = new System.Drawing.Point(223, 589);
            this.label25.MinimumSize = new System.Drawing.Size(100, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 100);
            this.label25.TabIndex = 48;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.Window;
            this.label26.Location = new System.Drawing.Point(534, 249);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(215, 25);
            this.label26.TabIndex = 49;
            this.label26.Text = "Choose your Crust!";
            // 
            // crust
            // 
            this.crust.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.crust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crust.FormattingEnabled = true;
            this.crust.Items.AddRange(new object[] {
            "Hand-Tossed",
            "Pan ",
            "Thin "});
            this.crust.Location = new System.Drawing.Point(562, 277);
            this.crust.Name = "crust";
            this.crust.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.crust.Size = new System.Drawing.Size(140, 32);
            this.crust.TabIndex = 50;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.Window;
            this.label28.Location = new System.Drawing.Point(282, 328);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(121, 20);
            this.label28.TabIndex = 53;
            this.label28.Text = "($1 per topping)";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.Window;
            this.label29.Location = new System.Drawing.Point(388, 400);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 20);
            this.label29.TabIndex = 54;
            this.label29.Text = "($1 per topping)";
            // 
            // beef
            // 
            this.beef.AutoSize = true;
            this.beef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.beef.FlatAppearance.BorderSize = 0;
            this.beef.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.beef.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beef.ForeColor = System.Drawing.SystemColors.Window;
            this.beef.Location = new System.Drawing.Point(396, 363);
            this.beef.Name = "beef";
            this.beef.Size = new System.Drawing.Size(71, 28);
            this.beef.TabIndex = 55;
            this.beef.Text = "Beef";
            this.beef.UseVisualStyleBackColor = true;
            // 
            // sausage
            // 
            this.sausage.AutoSize = true;
            this.sausage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.sausage.FlatAppearance.BorderSize = 0;
            this.sausage.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.sausage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sausage.ForeColor = System.Drawing.SystemColors.Window;
            this.sausage.Location = new System.Drawing.Point(495, 364);
            this.sausage.Name = "sausage";
            this.sausage.Size = new System.Drawing.Size(110, 28);
            this.sausage.TabIndex = 56;
            this.sausage.Text = "Sausage";
            this.sausage.UseVisualStyleBackColor = true;
            // 
            // ham
            // 
            this.ham.AutoSize = true;
            this.ham.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ham.FlatAppearance.BorderSize = 0;
            this.ham.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.ham.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ham.ForeColor = System.Drawing.SystemColors.Window;
            this.ham.Location = new System.Drawing.Point(626, 366);
            this.ham.Name = "ham";
            this.ham.Size = new System.Drawing.Size(72, 28);
            this.ham.TabIndex = 57;
            this.ham.Text = "Ham";
            this.ham.UseVisualStyleBackColor = true;
            // 
            // bacon
            // 
            this.bacon.AutoSize = true;
            this.bacon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bacon.FlatAppearance.BorderSize = 0;
            this.bacon.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.bacon.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bacon.ForeColor = System.Drawing.SystemColors.Window;
            this.bacon.Location = new System.Drawing.Point(721, 367);
            this.bacon.Name = "bacon";
            this.bacon.Size = new System.Drawing.Size(88, 28);
            this.bacon.TabIndex = 58;
            this.bacon.Text = "Bacon";
            this.bacon.UseVisualStyleBackColor = true;
            // 
            // chicken
            // 
            this.chicken.AutoSize = true;
            this.chicken.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.chicken.FlatAppearance.BorderSize = 0;
            this.chicken.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.chicken.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chicken.ForeColor = System.Drawing.SystemColors.Window;
            this.chicken.Location = new System.Drawing.Point(825, 368);
            this.chicken.Name = "chicken";
            this.chicken.Size = new System.Drawing.Size(105, 28);
            this.chicken.TabIndex = 59;
            this.chicken.Text = "Chicken";
            this.chicken.UseVisualStyleBackColor = true;
            // 
            // mush
            // 
            this.mush.AutoSize = true;
            this.mush.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.mush.FlatAppearance.BorderSize = 0;
            this.mush.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.mush.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mush.ForeColor = System.Drawing.SystemColors.Window;
            this.mush.Location = new System.Drawing.Point(234, 435);
            this.mush.Name = "mush";
            this.mush.Size = new System.Drawing.Size(138, 28);
            this.mush.TabIndex = 60;
            this.mush.Text = "Mushrooms";
            this.mush.UseVisualStyleBackColor = true;
            // 
            // onion
            // 
            this.onion.AutoSize = true;
            this.onion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.onion.FlatAppearance.BorderSize = 0;
            this.onion.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.onion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onion.ForeColor = System.Drawing.SystemColors.Window;
            this.onion.Location = new System.Drawing.Point(384, 434);
            this.onion.Name = "onion";
            this.onion.Size = new System.Drawing.Size(96, 28);
            this.onion.TabIndex = 61;
            this.onion.Text = "Onions";
            this.onion.UseVisualStyleBackColor = true;
            // 
            // greenPepp
            // 
            this.greenPepp.AutoSize = true;
            this.greenPepp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.greenPepp.FlatAppearance.BorderSize = 0;
            this.greenPepp.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.greenPepp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.greenPepp.ForeColor = System.Drawing.SystemColors.Window;
            this.greenPepp.Location = new System.Drawing.Point(495, 435);
            this.greenPepp.Name = "greenPepp";
            this.greenPepp.Size = new System.Drawing.Size(171, 28);
            this.greenPepp.TabIndex = 62;
            this.greenPepp.Text = "Green Peppers";
            this.greenPepp.UseVisualStyleBackColor = true;
            // 
            // tomato
            // 
            this.tomato.AutoSize = true;
            this.tomato.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tomato.FlatAppearance.BorderSize = 0;
            this.tomato.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.tomato.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tomato.ForeColor = System.Drawing.SystemColors.Window;
            this.tomato.Location = new System.Drawing.Point(681, 434);
            this.tomato.Name = "tomato";
            this.tomato.Size = new System.Drawing.Size(99, 28);
            this.tomato.TabIndex = 63;
            this.tomato.Text = "Tomato";
            this.tomato.UseVisualStyleBackColor = true;
            // 
            // pine
            // 
            this.pine.AutoSize = true;
            this.pine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pine.FlatAppearance.BorderSize = 0;
            this.pine.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.pine.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pine.ForeColor = System.Drawing.SystemColors.Window;
            this.pine.Location = new System.Drawing.Point(786, 434);
            this.pine.Name = "pine";
            this.pine.Size = new System.Drawing.Size(123, 28);
            this.pine.TabIndex = 64;
            this.pine.Text = "Pineapple";
            this.pine.UseVisualStyleBackColor = true;
            // 
            // bolives
            // 
            this.bolives.AutoSize = true;
            this.bolives.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.bolives.FlatAppearance.BorderSize = 0;
            this.bolives.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.bolives.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bolives.ForeColor = System.Drawing.SystemColors.Window;
            this.bolives.Location = new System.Drawing.Point(234, 485);
            this.bolives.Name = "bolives";
            this.bolives.Size = new System.Drawing.Size(143, 28);
            this.bolives.TabIndex = 65;
            this.bolives.Text = "Black Olives";
            this.bolives.UseVisualStyleBackColor = true;
            // 
            // jalapeno
            // 
            this.jalapeno.AutoSize = true;
            this.jalapeno.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.jalapeno.FlatAppearance.BorderSize = 0;
            this.jalapeno.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.jalapeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jalapeno.ForeColor = System.Drawing.SystemColors.Window;
            this.jalapeno.Location = new System.Drawing.Point(384, 488);
            this.jalapeno.Name = "jalapeno";
            this.jalapeno.Size = new System.Drawing.Size(114, 28);
            this.jalapeno.TabIndex = 66;
            this.jalapeno.Text = "Jalapeno";
            this.jalapeno.UseVisualStyleBackColor = true;
            // 
            // spin
            // 
            this.spin.AutoSize = true;
            this.spin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.spin.FlatAppearance.BorderSize = 0;
            this.spin.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.spin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spin.ForeColor = System.Drawing.SystemColors.Window;
            this.spin.Location = new System.Drawing.Point(504, 486);
            this.spin.Name = "spin";
            this.spin.Size = new System.Drawing.Size(105, 28);
            this.spin.TabIndex = 67;
            this.spin.Text = "Spinach";
            this.spin.UseVisualStyleBackColor = true;
            // 
            // exCheese
            // 
            this.exCheese.AutoSize = true;
            this.exCheese.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exCheese.FlatAppearance.BorderSize = 0;
            this.exCheese.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.exCheese.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exCheese.ForeColor = System.Drawing.SystemColors.Window;
            this.exCheese.Location = new System.Drawing.Point(633, 485);
            this.exCheese.Name = "exCheese";
            this.exCheese.Size = new System.Drawing.Size(155, 28);
            this.exCheese.TabIndex = 68;
            this.exCheese.Text = "Extra Cheese";
            this.exCheese.UseVisualStyleBackColor = true;
            // 
            // feta
            // 
            this.feta.AutoSize = true;
            this.feta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.feta.FlatAppearance.BorderSize = 0;
            this.feta.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.feta.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feta.ForeColor = System.Drawing.SystemColors.Window;
            this.feta.Location = new System.Drawing.Point(804, 485);
            this.feta.Name = "feta";
            this.feta.Size = new System.Drawing.Size(148, 28);
            this.feta.TabIndex = 69;
            this.feta.Text = "Feta Cheese";
            this.feta.UseVisualStyleBackColor = true;
            // 
            // BYO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(1133, 710);
            this.Controls.Add(this.feta);
            this.Controls.Add(this.exCheese);
            this.Controls.Add(this.spin);
            this.Controls.Add(this.jalapeno);
            this.Controls.Add(this.bolives);
            this.Controls.Add(this.pine);
            this.Controls.Add(this.tomato);
            this.Controls.Add(this.greenPepp);
            this.Controls.Add(this.onion);
            this.Controls.Add(this.mush);
            this.Controls.Add(this.chicken);
            this.Controls.Add(this.bacon);
            this.Controls.Add(this.ham);
            this.Controls.Add(this.sausage);
            this.Controls.Add(this.beef);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.crust);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.pepp);
            this.Controls.Add(this.notes);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.sauce);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.size);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "BYO";
            this.Text = "BYO";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox size;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox sauce;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox notes;
        private System.Windows.Forms.CheckBox pepp;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox crust;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.CheckBox beef;
        private System.Windows.Forms.CheckBox sausage;
        private System.Windows.Forms.CheckBox ham;
        private System.Windows.Forms.CheckBox bacon;
        private System.Windows.Forms.CheckBox chicken;
        private System.Windows.Forms.CheckBox mush;
        private System.Windows.Forms.CheckBox onion;
        private System.Windows.Forms.CheckBox greenPepp;
        private System.Windows.Forms.CheckBox tomato;
        private System.Windows.Forms.CheckBox pine;
        private System.Windows.Forms.CheckBox bolives;
        private System.Windows.Forms.CheckBox jalapeno;
        private System.Windows.Forms.CheckBox spin;
        private System.Windows.Forms.CheckBox exCheese;
        private System.Windows.Forms.CheckBox feta;
    }
}