﻿namespace $safeprojectname$
{
    partial class Appetizers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appetizers));
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.wing10 = new System.Windows.Forms.CheckBox();
            this.wing20 = new System.Windows.Forms.CheckBox();
            this.wing30 = new System.Windows.Forms.CheckBox();
            this.wingSauce = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Image = ((System.Drawing.Image)(resources.GetObject("label25.Image")));
            this.label25.Location = new System.Drawing.Point(1165, 9);
            this.label25.MinimumSize = new System.Drawing.Size(100, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 100);
            this.label25.TabIndex = 56;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Image = ((System.Drawing.Image)(resources.GetObject("label24.Image")));
            this.label24.Location = new System.Drawing.Point(1079, 6);
            this.label24.MinimumSize = new System.Drawing.Size(70, 100);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 100);
            this.label24.TabIndex = 55;
            this.label24.Text = "label24";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Image = ((System.Drawing.Image)(resources.GetObject("label23.Image")));
            this.label23.Location = new System.Drawing.Point(975, 9);
            this.label23.MinimumSize = new System.Drawing.Size(70, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 100);
            this.label23.TabIndex = 54;
            this.label23.Text = "label23";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(430, 67);
            this.label4.MinimumSize = new System.Drawing.Size(430, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(430, 80);
            this.label4.TabIndex = 53;
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(12, -20);
            this.label2.MaximumSize = new System.Drawing.Size(300, 500);
            this.label2.MinimumSize = new System.Drawing.Size(190, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 200);
            this.label2.TabIndex = 52;
            this.label2.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(53, 192);
            this.label1.MinimumSize = new System.Drawing.Size(1200, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1200, 150);
            this.label1.TabIndex = 57;
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(33, 339);
            this.label3.MinimumSize = new System.Drawing.Size(1200, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1200, 150);
            this.label3.TabIndex = 58;
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox8.FlatAppearance.BorderSize = 0;
            this.checkBox8.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox8.Location = new System.Drawing.Point(243, 325);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(151, 28);
            this.checkBox8.TabIndex = 62;
            this.checkBox8.Text = "Large - $6.99";
            this.checkBox8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox7.FlatAppearance.BorderSize = 0;
            this.checkBox7.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox7.Location = new System.Drawing.Point(78, 325);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox7.Size = new System.Drawing.Size(149, 28);
            this.checkBox7.TabIndex = 61;
            this.checkBox7.Text = "Small - $3.99";
            this.checkBox7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // wing10
            // 
            this.wing10.AutoSize = true;
            this.wing10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.wing10.FlatAppearance.BorderSize = 0;
            this.wing10.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.wing10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wing10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.wing10.Location = new System.Drawing.Point(78, 471);
            this.wing10.Name = "wing10";
            this.wing10.Size = new System.Drawing.Size(148, 28);
            this.wing10.TabIndex = 80;
            this.wing10.Text = "10 ct. - $8.99";
            this.wing10.UseVisualStyleBackColor = true;
            // 
            // wing20
            // 
            this.wing20.AutoSize = true;
            this.wing20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.wing20.FlatAppearance.BorderSize = 0;
            this.wing20.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.wing20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wing20.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.wing20.Location = new System.Drawing.Point(243, 470);
            this.wing20.Name = "wing20";
            this.wing20.Size = new System.Drawing.Size(159, 28);
            this.wing20.TabIndex = 82;
            this.wing20.Text = "20 ct. - $16.99";
            this.wing20.UseVisualStyleBackColor = true;
            // 
            // wing30
            // 
            this.wing30.AutoSize = true;
            this.wing30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.wing30.FlatAppearance.BorderSize = 0;
            this.wing30.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.wing30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wing30.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.wing30.Location = new System.Drawing.Point(153, 507);
            this.wing30.Name = "wing30";
            this.wing30.Size = new System.Drawing.Size(159, 28);
            this.wing30.TabIndex = 84;
            this.wing30.Text = "30 ct. - $27.99";
            this.wing30.UseVisualStyleBackColor = true;
            // 
            // wingSauce
            // 
            this.wingSauce.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.wingSauce.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wingSauce.FormattingEnabled = true;
            this.wingSauce.Items.AddRange(new object[] {
            "Hot",
            "Mild",
            "BBQ",
            "Garlic"});
            this.wingSauce.Location = new System.Drawing.Point(122, 574);
            this.wingSauce.Name = "wingSauce";
            this.wingSauce.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.wingSauce.Size = new System.Drawing.Size(140, 32);
            this.wingSauce.TabIndex = 86;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.Window;
            this.label18.Location = new System.Drawing.Point(95, 542);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(225, 25);
            this.label18.TabIndex = 85;
            this.label18.Text = "Choose your Sauce!";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Image = ((System.Drawing.Image)(resources.GetObject("label19.Image")));
            this.label19.Location = new System.Drawing.Point(413, 574);
            this.label19.MinimumSize = new System.Drawing.Size(430, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(430, 60);
            this.label19.TabIndex = 87;
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // textBox8
            // 
            this.textBox8.AccessibleName = "";
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBox8.Location = new System.Drawing.Point(937, 556);
            this.textBox8.MaximumSize = new System.Drawing.Size(250, 100);
            this.textBox8.MinimumSize = new System.Drawing.Size(150, 70);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(226, 70);
            this.textBox8.TabIndex = 89;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.Window;
            this.label20.Location = new System.Drawing.Point(958, 526);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(158, 25);
            this.label20.TabIndex = 88;
            this.label20.Text = "Special Notes";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox5.FlatAppearance.BorderSize = 0;
            this.checkBox5.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox5.Location = new System.Drawing.Point(651, 478);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(151, 28);
            this.checkBox5.TabIndex = 91;
            this.checkBox5.Text = "Large - $6.99";
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox6.FlatAppearance.BorderSize = 0;
            this.checkBox6.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox6.Location = new System.Drawing.Point(486, 478);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox6.Size = new System.Drawing.Size(149, 28);
            this.checkBox6.TabIndex = 90;
            this.checkBox6.Text = "Small - $3.99";
            this.checkBox6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox1.FlatAppearance.BorderSize = 0;
            this.checkBox1.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox1.Location = new System.Drawing.Point(651, 317);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(151, 28);
            this.checkBox1.TabIndex = 93;
            this.checkBox1.Text = "Large - $5.99";
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox2.FlatAppearance.BorderSize = 0;
            this.checkBox2.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox2.Location = new System.Drawing.Point(486, 317);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox2.Size = new System.Drawing.Size(149, 28);
            this.checkBox2.TabIndex = 92;
            this.checkBox2.Text = "Small - $2.99";
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox3.FlatAppearance.BorderSize = 0;
            this.checkBox3.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox3.Location = new System.Drawing.Point(1059, 314);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(151, 28);
            this.checkBox3.TabIndex = 95;
            this.checkBox3.Text = "Large - $8.69";
            this.checkBox3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox4.FlatAppearance.BorderSize = 0;
            this.checkBox4.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox4.Location = new System.Drawing.Point(894, 314);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox4.Size = new System.Drawing.Size(149, 28);
            this.checkBox4.TabIndex = 94;
            this.checkBox4.Text = "Small - $4.99";
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.checkBox9.FlatAppearance.BorderSize = 0;
            this.checkBox9.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox9.Location = new System.Drawing.Point(1071, 470);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(151, 28);
            this.checkBox9.TabIndex = 97;
            this.checkBox9.Text = "Large - $3.49";
            this.checkBox9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.checkBox10.FlatAppearance.BorderSize = 0;
            this.checkBox10.FlatAppearance.CheckedBackColor = System.Drawing.Color.White;
            this.checkBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.checkBox10.Location = new System.Drawing.Point(906, 470);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.checkBox10.Size = new System.Drawing.Size(149, 28);
            this.checkBox10.TabIndex = 96;
            this.checkBox10.Text = "Small - $1.99";
            this.checkBox10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // Appetizers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(1293, 644);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.wingSauce);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.wing30);
            this.Controls.Add(this.wing20);
            this.Controls.Add(this.wing10);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Appetizers";
            this.Text = "Appetizers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox wing10;
        private System.Windows.Forms.CheckBox wing20;
        private System.Windows.Forms.CheckBox wing30;
        private System.Windows.Forms.ComboBox wingSauce;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
    }
}